// Evaluación principal del sistema.
//   node tests/evaluar-sistema.mjs
//
// Responde: ¿qué tan bien clasifica lo que el usuario realmente ve?
// Toda la lógica de medición vive en tests/lib/evaluacion.mjs, compartida con
// evaluar-auditoria.mjs para que ambos informes no puedan discrepar.

import { entrenar } from "../js/motor/modelo.js";
import { UMBRAL } from "../js/motor/decision.js";
import {
  ADVERTENCIA, cargarTodo, cvEstratificada, resumenCv, retencionRepetida,
  evaluarConfiguraciones, imprimirMetricas, porcentaje,
} from "./lib/evaluacion.mjs";

const { corpus, config, externo } = cargarTodo();

console.log(ADVERTENCIA);
console.log(`\nUmbral de decisión del clasificador: ${UMBRAL}\n`);

/* ---------- corpus semilla ---------- */

console.log(`=== Corpus semilla (${corpus.length} mensajes, SINTÉTICO) ===`);

const cv = resumenCv(cvEstratificada(corpus, 5));
console.log(
  `CV estratificada 5-fold          exactitud=${porcentaje(cv.media)} ± ${(cv.de * 100).toFixed(1)} pp ` +
  `(rango ${porcentaje(cv.min)}–${porcentaje(cv.max)})   <- protocolo principal`,
);

const ret = retencionRepetida(corpus);
console.log(
  `Retención 70/30, 10 semillas     exactitud=${porcentaje(ret.media)} ` +
  `(rango ${porcentaje(ret.min)}–${porcentaje(ret.max)})   <- protocolo anterior, solo comparación`,
);

/* ---------- conjunto externo ---------- */

const modelo = entrenar(corpus);
const r = evaluarConfiguraciones(modelo, config, externo);

console.log(`\n=== Conjunto externo (${externo.length} mensajes, SINTÉTICO, escrito por la auditoría) ===`);
imprimirMetricas("Solo el modelo", r.modelo);
imprimirMetricas("Solo las reglas", r.reglas);
imprimirMetricas("SISTEMA FINAL (modelo + piso)", r.sistema);

console.log(
  "\nEl sistema final es lo que ve el usuario: el clasificador decide la etiqueta\n" +
  "y las reglas solo pueden elevar el nivel de alerta, nunca bajarlo\n" +
  "(contrato en js/motor/decision.js, probado en tests/decision.test.js).",
);

const bajaFn = r.modelo.fn - r.sistema.fn;
const subeFp = r.sistema.fp - r.modelo.fp;
console.log(
  `\nEfecto del piso de reglas: los falsos negativos bajan de ${r.modelo.fn} a ${r.sistema.fn} ` +
  `(${bajaFn} menos) a cambio de ${subeFp} falsas alarmas más.`,
);
