// Pruebas del clasificador entrenable.

import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { tokenizar, entrenar, predecir, aprender, evaluar, nivelConfianza } from "../js/motor/modelo.js";

const corpus = JSON.parse(readFileSync(new URL("../config/corpus-semilla.json", import.meta.url), "utf8"));
const EJEMPLOS = corpus.mensajes;

test("el corpus semilla está declarado como sintético", () => {
  assert.equal(corpus.origen, "SINTÉTICO");
  assert.ok(EJEMPLOS.length >= 100, "la semilla debe tener al menos 100 ejemplos");
});

test("el corpus está razonablemente balanceado", () => {
  const phishing = EJEMPLOS.filter((e) => e.e === 1).length;
  const proporcion = phishing / EJEMPLOS.length;
  assert.ok(proporcion > 0.4 && proporcion < 0.6, `proporción desbalanceada: ${proporcion}`);
});

test("tokenizar quita tildes, palabras vacías y agrupa cifras", () => {
  const t = tokenizar("Confirmación urgente: paga 45000 pesos");
  assert.ok(t.includes("confirmacion"));
  assert.ok(t.includes("urgente"));
  assert.ok(t.includes("«cifra»"), "las cifras sueltas se agrupan");
  assert.ok(!t.includes("que"), "las palabras vacías se descartan");
});

test("tokenizar marca enlaces y montos", () => {
  const t = tokenizar("Entra a bancolombia-seguro.co y paga $80.000");
  assert.ok(t.includes("«enlace»"));
  assert.ok(t.includes("«monto»"));
});

test("un modelo sin ejemplos devuelve 0.5 y confianza nula", () => {
  const m = entrenar([]);
  const p = predecir(m, "cualquier cosa");
  assert.equal(p.probabilidad, 0.5);
  assert.equal(p.confianza, "ninguna");
});

test("clasifica phishing evidente por encima de 0.5", () => {
  const m = entrenar(EJEMPLOS);
  const p = predecir(m, "Bancolombia: tu cuenta será bloqueada, confirma tu clave en bancolombia-verifica.co");
  assert.ok(p.probabilidad > 0.5, `probabilidad obtenida: ${p.probabilidad}`);
});

test("clasifica un mensaje cotidiano por debajo de 0.5", () => {
  const m = entrenar(EJEMPLOS);
  const p = predecir(m, "Mamá ya voy saliendo de la universidad, llego en una hora");
  assert.ok(p.probabilidad < 0.5, `probabilidad obtenida: ${p.probabilidad}`);
});

test("un código legítimo con 'no lo compartas' no se marca como phishing", () => {
  const m = entrenar(EJEMPLOS);
  const p = predecir(m, "Tu código de verificación es 482913. No lo compartas con nadie.");
  assert.ok(p.probabilidad < 0.5, `probabilidad obtenida: ${p.probabilidad}`);
});

test("la predicción explica qué palabras pesaron", () => {
  const m = entrenar(EJEMPLOS);
  const p = predecir(m, "Ganaste un premio, consigna el impuesto hoy");
  assert.ok(p.palabras.length > 0, "debe devolver palabras con peso");
  for (const w of p.palabras) {
    assert.equal(typeof w.palabra, "string");
    assert.equal(typeof w.peso, "number");
  }
});

test("aprender mueve la predicción hacia la etiqueta enseñada", () => {
  const m = entrenar(EJEMPLOS);
  const texto = "quiubo parcero nos vemos en el parque a las cinco";
  const antes = predecir(m, texto).probabilidad;
  for (let i = 0; i < 6; i++) aprender(m, texto, 1);
  const despues = predecir(m, texto).probabilidad;
  assert.ok(despues > antes, `no aprendió: ${antes} → ${despues}`);
});

test("aprender aumenta el conteo de ejemplos", () => {
  const m = entrenar(EJEMPLOS);
  const antes = m.ejemplos;
  aprender(m, "un mensaje nuevo cualquiera", 0);
  assert.equal(m.ejemplos, antes + 1);
});

test("la confianza es baja con pocos ejemplos o pocas palabras conocidas", () => {
  assert.equal(nivelConfianza(10, 50), "baja");
  assert.equal(nivelConfianza(1000, 1), "baja");
  assert.equal(nivelConfianza(1000, 10), "alta");
});

test("la evaluación se hace sobre datos apartados y es reproducible", () => {
  const a = evaluar(EJEMPLOS, 0.3, 7);
  const b = evaluar(EJEMPLOS, 0.3, 7);
  assert.deepEqual(a, b, "misma semilla debe dar el mismo resultado");
  assert.ok(a.n > 0 && a.n < EJEMPLOS.length, "la partición de prueba debe ser un subconjunto");
  assert.equal(a.vp + a.vn + a.fp + a.fn, a.n);
});

test("el desempeño sobre el corpus semilla supera el azar", () => {
  const r = evaluar(EJEMPLOS, 0.3, 7);
  assert.ok(r.exactitud > 0.7, `exactitud muy baja: ${r.exactitud}`);
});
