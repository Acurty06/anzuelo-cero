import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

import { analizar } from "../js/motor/analizar.js";
import { levenshtein, clasificarHost, extraerHosts } from "../js/motor/paginas.js";
import { recomendar } from "../js/motor/recomendaciones.js";
import { VEREDICTOS } from "../js/motor/veredicto.js";

const raiz = join(dirname(fileURLToPath(import.meta.url)), "..");
const config = JSON.parse(readFileSync(join(raiz, "config", "reglas.json"), "utf8"));

const tipos = (r) => r.senales.map((s) => s.tipo);

test("levenshtein calcula distancias básicas", () => {
  assert.equal(levenshtein("bancolombia", "bancolombla"), 1);
  assert.equal(levenshtein("abc", "abc"), 0);
});

test("dominio oficial no suma riesgo", () => {
  assert.equal(clasificarHost("bancolombia.com", config), "oficial");
});

test("dominio con error ortográfico frente a una marca es imitación", () => {
  assert.equal(clasificarHost("bancolombla.com", config), "imitacion");
});

test("dominio que contiene una marca pero no es oficial es imitación", () => {
  assert.equal(clasificarHost("bancolombia-seguro.xyz", config), "imitacion");
});

test("enlace acortado se clasifica como acortado", () => {
  assert.equal(clasificarHost("bit.ly", config), "acortado");
});

test("extraerHosts encuentra URLs en el texto y en el campo", () => {
  const hosts = extraerHosts("entra a https://bancolombla.com/login", "bit.ly/abc");
  assert.ok(hosts.includes("bancolombla.com"));
  assert.ok(hosts.includes("bit.ly"));
});

test("mensaje de empleo con pago y datos es Peligroso", () => {
  const r = analizar({
    texto: "Hola, vi tu perfil. Tenemos vacante de asistente de datos con pago semanal de $800.000. Solo necesitamos tu cédula y una consignación de $50.000 para el curso de ingreso.",
  }, {}, config);
  assert.equal(r.veredicto, VEREDICTOS.PELIGROSO);
  assert.ok(tipos(r).includes("pide_pago"));
  assert.ok(tipos(r).includes("pide_datos"));
});

test("alerta de banco con urgencia y enlace imitado es Peligroso o Sospechoso", () => {
  const r = analizar({
    texto: "Alerta: detectamos un movimiento inusual en tu cuenta. Confirma ahora tu clave en bancolombla.com o la cuenta será bloqueada en 2 horas.",
  }, {}, config);
  assert.ok([VEREDICTOS.PELIGROSO, VEREDICTOS.SOSPECHOSO].includes(r.veredicto));
  assert.ok(tipos(r).includes("dominio_imitacion"));
  assert.ok(tipos(r).includes("urgencia"));
});

test("'hola hijo necesito 10k' es No concluyente y pide verificar por otro medio", () => {
  const r = analizar({ texto: "hola hijo necesito 10k" }, {}, config);
  assert.equal(r.fase, "preguntas");
  assert.equal(r.veredicto, null);
  assert.equal(r.pregunta.id, "numero_guardado");
  const recs = recomendar(r.senales);
  assert.ok(recs.some((t) => t.includes("contacta a esa persona por otro medio")));
});

test("respuesta 'número no guardado' sube el puntaje; nunca pasa a Sin señales", () => {
  const r = analizar(
    { texto: "hola hijo necesito 10k" },
    { numero_guardado: false, confirmo_otro_medio: false },
    config,
  );
  assert.equal(r.fase, "final");
  assert.notEqual(r.veredicto, VEREDICTOS.SIN_SENALES);
});

test("solicitud de dinero nunca queda en Sin señales aunque se confirme por otro medio", () => {
  const r = analizar(
    { texto: "hola hijo necesito 10k" },
    { numero_guardado: true, confirmo_otro_medio: true },
    config,
  );
  assert.equal(r.fase, "final");
  assert.equal(r.veredicto, VEREDICTOS.NO_CONCLUYENTE);
  assert.equal(r.pregunta, null);
});

test("recordatorio legítimo sin enlace es Sin señales de alerta", () => {
  const r = analizar({
    texto: "Recordatorio: la reunión del grupo es el jueves a las 3 p. m. en la biblioteca.",
  }, {}, config);
  assert.equal(r.veredicto, VEREDICTOS.SIN_SENALES);
});

test("mensaje con 'no la compartas' no activa la señal de datos", () => {
  const r = analizar({
    texto: "Tu clave de un solo uso es 482913. No la compartas con nadie.",
  }, {}, config);
  assert.ok(!tipos(r).includes("pide_datos"));
});

test("aviso de entrega con 'enlace de la app oficial' queda No concluyente, no Sin señales", () => {
  const r = analizar({
    texto: "Tu pedido de la tienda fue despachado. Puedes seguir el envío en el enlace de la app oficial.",
  }, {}, config);
  assert.equal(r.fase, "preguntas");
  assert.equal(r.pregunta.id, "esperado");
});

test("premio que exige pagar un cargo activa premio_con_pago", () => {
  const r = analizar({
    texto: "Felicidades, ganaste un premio de $2.000.000 en nuestra rifa. Para reclamarlo paga un impuesto de $80.000 hoy.",
  }, {}, config);
  assert.ok(tipos(r).includes("premio_con_pago"));
  assert.notEqual(r.veredicto, VEREDICTOS.SIN_SENALES);
});

test("entrada vacía devuelve error y no un veredicto", () => {
  const r = analizar({ texto: "   ", url: "" }, {}, config);
  assert.ok(r.error);
});
