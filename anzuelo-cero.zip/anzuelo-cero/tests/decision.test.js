// Pruebas del contrato de decisión: el modelo gobierna la etiqueta, las reglas
// solo pueden subir la cautela.

import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { entrenar } from "../js/motor/modelo.js";
import { detectarSenales } from "../js/motor/senales.js";
import { normalizar } from "../js/motor/paginas.js";
import { VEREDICTOS } from "../js/motor/veredicto.js";
import {
  ETIQUETAS, UMBRAL, UMBRAL_ALTO,
  clasificarConModelo, pisoDeReglas, veredictoDelModelo, decidir,
} from "../js/motor/decision.js";

const config = JSON.parse(readFileSync(new URL("../config/reglas.json", import.meta.url), "utf8"));
const corpus = JSON.parse(readFileSync(new URL("../config/corpus-semilla.json", import.meta.url), "utf8")).mensajes;
const modelo = entrenar(corpus);

const senalesDe = (texto, url = "") => detectarSenales(normalizar(texto), url, config);

/* ---------- la decisión es del modelo ---------- */

test("el umbral documentado es 0.5 y no se movió para ajustar métricas", () => {
  assert.equal(UMBRAL, 0.5);
});

test("clasificarConModelo devuelve etiqueta, puntuación y explicación", () => {
  const d = clasificarConModelo(modelo, "Confirma tu clave en bancolombia-seguro.co antes de 2 horas");
  assert.equal(d.etiqueta, ETIQUETAS.PHISHING);
  assert.ok(d.puntuacion >= UMBRAL);
  assert.ok(Array.isArray(d.palabras));
  assert.ok(typeof d.confianza === "string");
});

test("un mensaje cotidiano se clasifica como legítimo", () => {
  const d = clasificarConModelo(modelo, "Mamá ya voy saliendo de la universidad, llego en una hora");
  assert.equal(d.etiqueta, ETIQUETAS.LEGITIMO);
});

test("el veredicto base sale solo del modelo, sin mirar las reglas", () => {
  assert.equal(veredictoDelModelo({ etiqueta: ETIQUETAS.LEGITIMO, puntuacion: 0.01 }), VEREDICTOS.SIN_SENALES);
  assert.equal(veredictoDelModelo({ etiqueta: ETIQUETAS.PHISHING, puntuacion: 0.6 }), VEREDICTOS.SOSPECHOSO);
  assert.equal(veredictoDelModelo({ etiqueta: ETIQUETAS.PHISHING, puntuacion: UMBRAL_ALTO }), VEREDICTOS.PELIGROSO);
});

/* ---------- las reglas solo suben ---------- */

test("sin evidencia dura, las reglas no imponen ningún piso", () => {
  assert.equal(pisoDeReglas([]), VEREDICTOS.SIN_SENALES);
  assert.equal(pisoDeReglas([{ tipo: "urgencia" }]), VEREDICTOS.SIN_SENALES);
});

test("una petición de dinero o datos impone al menos No concluyente", () => {
  for (const tipo of ["pide_pago", "pide_datos", "premio_con_pago", "solicitud_dinero_sin_pago"]) {
    assert.equal(pisoDeReglas([{ tipo }]), VEREDICTOS.NO_CONCLUYENTE, `falló con ${tipo}`);
  }
});

test("la evidencia de enlace impone al menos Sospechoso", () => {
  assert.equal(pisoDeReglas([{ tipo: "dominio_imitacion" }]), VEREDICTOS.SOSPECHOSO);
  assert.equal(pisoDeReglas([{ tipo: "enlace_acortado" }]), VEREDICTOS.SOSPECHOSO);
});

test("las reglas nunca bajan el veredicto del modelo", () => {
  // El modelo está muy seguro de que es phishing; las reglas no ven nada.
  const r = decidir(modelo, "Confirma tu clave ahora o tu cuenta será bloqueada en 2 horas", []);
  assert.equal(r.base, r.veredicto, "sin piso, el veredicto debe ser exactamente el del modelo");
  assert.equal(r.reglasSubieron, false);
});

test("ante desacuerdo la etiqueta final sigue siendo la del modelo", () => {
  const texto = "Mamá ya voy saliendo de la universidad, llego en una hora";
  const r = decidir(modelo, texto, senalesDe("necesito 10k urgente"));
  assert.equal(r.decision.etiqueta, ETIQUETAS.LEGITIMO, "el modelo mantiene su etiqueta");
  assert.ok(r.desacuerdo, "debe marcarse el desacuerdo para mostrarlo al usuario");
  // Pero el piso levanta la cautela.
  assert.notEqual(r.veredicto, VEREDICTOS.SIN_SENALES);
});

/* ---------- el invariante de seguridad sobrevive ---------- */

test("una petición de datos nunca queda en Sin señales aunque el modelo la crea legítima", () => {
  const texto = "Escribe tu clave aquí para validar tu cuenta";
  const senales = senalesDe(texto);
  const r = decidir(modelo, texto, senales);
  assert.notEqual(r.veredicto, VEREDICTOS.SIN_SENALES);
});

test("el invariante se sostiene incluso forzando al modelo a decir legítimo", () => {
  // Modelo degenerado que clasifica todo como legítimo.
  const trivial = entrenar([{ t: "hola que mas como vas todo bien por aca", e: 0 }]);
  for (const tipo of ["pide_pago", "pide_datos", "premio_con_pago", "solicitud_dinero_sin_pago"]) {
    const r = decidir(trivial, "cualquier texto inocuo", [{ tipo }]);
    assert.equal(r.decision.etiqueta, ETIQUETAS.LEGITIMO);
    assert.notEqual(r.veredicto, VEREDICTOS.SIN_SENALES, `el piso falló con ${tipo}`);
  }
});

test("un dominio que imita una marca levanta la alarma aunque el texto parezca inocuo", () => {
  const texto = "Hola, mira esto cuando puedas";
  const senales = senalesDe(texto, "bancolombia-seguro.co/validar");
  const r = decidir(modelo, texto, senales);
  assert.ok(r.reglasSubieron, "las reglas deben subir el nivel");
  assert.notEqual(r.veredicto, VEREDICTOS.SIN_SENALES);
});

/* ---------- consistencia general ---------- */

test("el veredicto final nunca es inferior al del modelo ni al piso", () => {
  const ORDEN = [VEREDICTOS.SIN_SENALES, VEREDICTOS.NO_CONCLUYENTE, VEREDICTOS.SOSPECHOSO, VEREDICTOS.PELIGROSO];
  const casos = [
    "hola hijo necesito 10k",
    "Ganaste un premio, consigna el impuesto hoy",
    "Recordatorio: la reunión es el jueves a las 3",
    "Tu código es 482913. No lo compartas con nadie.",
    "Confirma tu clave en bancolombla.com",
  ];
  for (const texto of casos) {
    const r = decidir(modelo, texto, senalesDe(texto));
    assert.ok(ORDEN.indexOf(r.veredicto) >= ORDEN.indexOf(r.base), `bajó respecto al modelo: ${texto}`);
    assert.ok(ORDEN.indexOf(r.veredicto) >= ORDEN.indexOf(r.piso), `bajó respecto al piso: ${texto}`);
  }
});
