// Pruebas de regresión de la auditoría adversaria del 5 de noviembre de 2026.
// Los cuatro fallos que la auditoría encontró están corregidos y verificados
// aquí. Ninguna prueba de este archivo debe debilitarse ni marcarse como TODO.

import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { analizar, MAX_CARACTERES } from "../js/motor/analizar.js";
import { clasificarHost, compactar, extraerHosts, levenshtein } from "../js/motor/paginas.js";
import { VEREDICTOS } from "../js/motor/veredicto.js";

const config = JSON.parse(readFileSync(new URL("../config/reglas.json", import.meta.url), "utf8"));

const tipos = (r) => r.senales.map((s) => s.tipo);

/* ---------- Fallo 1 (crítico): la negación anulaba toda la detección ---------- */

test("una petición de clave precedida por una negación nunca termina en Sin señales", () => {
  const r = analizar({ texto: "No compartas tu clave conmigo; escríbela aquí para validar" }, {}, config);
  assert.notEqual(r.veredicto, VEREDICTOS.SIN_SENALES);
  assert.ok(tipos(r).includes("pide_datos"));
});

test("la negación sigue anulando la señal en la entrega legítima de un código", () => {
  const r = analizar({ texto: "Tu clave de un solo uso es 482913. No la compartas con nadie." }, {}, config);
  assert.ok(!tipos(r).includes("pide_datos"));
  assert.equal(r.veredicto, VEREDICTOS.SIN_SENALES);
});

test("un código legítimo con marca de por medio tampoco activa la señal", () => {
  const r = analizar({ texto: "Tu código de verificación de WhatsApp es 482-913. No lo compartas con nadie." }, {}, config);
  assert.ok(!tipos(r).includes("pide_datos"));
});

/* ---------- Fallos 2 y 3 (alto): evasión por separadores y homóglifos ---------- */

test("una clave separada por puntos se detecta como solicitud de datos", () => {
  const r = analizar({ texto: "Escribe tu c.l.a.v.e ahora" }, {}, config);
  assert.ok(tipos(r).includes("pide_datos"));
});

test("una clave con emoji intercalado se detecta como solicitud de datos", () => {
  const r = analizar({ texto: "Manda tu c🔐l🔐a🔐v🔐e" }, {}, config);
  assert.ok(tipos(r).includes("pide_datos"));
});

test("una clave separada por espacios se detecta como solicitud de datos", () => {
  const r = analizar({ texto: "Escribe tu c l a v e aquí" }, {}, config);
  assert.ok(tipos(r).includes("pide_datos"));
});

test("homóglifos latinos y cirílicos no evaden el diccionario", () => {
  const arroba = analizar({ texto: "Envíame tu cl@ve de Bancolombia" }, {}, config);
  assert.ok(tipos(arroba).includes("pide_datos"));
  const cirilico = analizar({ texto: "Escribe tu с l a v e aquí" }, {}, config);
  assert.ok(tipos(cirilico).includes("pide_datos"));
});

test("compactar no une palabras normales ni destroza cifras", () => {
  const { texto } = compactar("tu pedido 482913 llega hoy entre 2 y 6 pm");
  assert.ok(texto.includes("482913"), "las cifras sueltas se conservan");
  assert.ok(texto.includes("pedido"), "las palabras normales se conservan");
});

test("compactar devuelve el fragmento original para poder resaltarlo", () => {
  const { tramos } = compactar("escribe tu c.l.a.v.e ahora");
  const tramo = tramos.find((t) => t.compacto === "clave");
  assert.ok(tramo, "debe registrar el tramo colapsado");
  assert.equal(tramo.original, "c.l.a.v.e");
});

/* ---------- Fallo 4 (medio): subdominios oficiales ---------- */

test("un subdominio de un dominio oficial no se confunde con un atacante", () => {
  assert.equal(clasificarHost("pagos.bancolombia.com", config), "oficial");
  assert.equal(clasificarHost("sucursal.davivienda.com", config), "oficial");
});

test("un dominio oficial seguido por un dominio atacante no se considera oficial", () => {
  assert.equal(clasificarHost("bancolombia.com.atacante.co", config), "imitacion");
});

test("una imitación por una letra cambiada se sigue detectando", () => {
  assert.equal(clasificarHost("bancolombla.com", config), "imitacion");
});

/* ---------- Robustez de entrada ---------- */

test("una entrada excesivamente larga se rechaza con un mensaje claro", () => {
  const r = analizar({ texto: "a".repeat(MAX_CARACTERES + 1) }, {}, config);
  assert.ok(r.error, "debe devolver error");
  assert.ok(r.error.includes(String(MAX_CARACTERES)));
  assert.equal(r.veredicto, undefined);
});

test("una entrada justo en el límite sí se analiza", () => {
  const r = analizar({ texto: "clave ".repeat(100).slice(0, MAX_CARACTERES) }, {}, config);
  assert.ok(!r.error);
});

test("HTML crudo se trata como texto y no altera el veredicto", () => {
  const r = analizar({ texto: '<img src=x onerror=alert(1)> clave' }, {}, config);
  assert.equal(r.veredicto, VEREDICTOS.SOSPECHOSO);
});

test("entrada de solo emoji no provoca error", () => {
  const r = analizar({ texto: "🚨🔐💸" }, {}, config);
  assert.equal(r.fase, "final");
  assert.equal(r.veredicto, VEREDICTOS.SIN_SENALES);
});

/* ---------- Utilidades de dominio ---------- */

test("extraerHosts conserva hosts con puerto y elimina el puerto", () => {
  assert.deepEqual(extraerHosts("", "HTTPS://BANCLOMBIA.COM:8080/validar"), ["banclombia.com"]);
});

test("extraerHosts encuentra más de un dominio en un mensaje", () => {
  const hosts = extraerHosts("Compara https://bit.ly/a con ejemplo.xyz y no abras nada", "");
  assert.ok(hosts.includes("bit.ly"));
  assert.ok(hosts.includes("ejemplo.xyz"));
});

test("levenshtein conserva simetría y los casos vacíos", () => {
  assert.equal(levenshtein("", "abc"), 3);
  assert.equal(levenshtein("abc", ""), 3);
  assert.equal(levenshtein("claro", "clrao"), levenshtein("clrao", "claro"));
});

/* ---------- Invariante de seguridad ---------- */

test("ninguna combinación de respuestas lleva una petición de datos a Sin señales", () => {
  const combinaciones = [
    { numero_guardado: true, confirmo_otro_medio: true },
    { esperado: true },
    { numero_guardado: true, esperado: true },
  ];
  for (const respuestas of combinaciones) {
    const r = analizar({ texto: "Escribe tu clave aquí para validar tu cuenta" }, respuestas, config);
    assert.notEqual(r.veredicto, VEREDICTOS.SIN_SENALES, `falló con ${JSON.stringify(respuestas)}`);
  }
});

test("el puntaje nunca queda negativo", () => {
  const r = analizar(
    { texto: "hola hijo necesito 10k" },
    { numero_guardado: true, confirmo_otro_medio: true },
    config,
  );
  assert.ok(r.puntaje >= 0, `puntaje negativo: ${r.puntaje}`);
});
