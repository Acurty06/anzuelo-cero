// Informe de la auditoría adversaria.
//   node tests/evaluar-auditoria.mjs
//
// Complementa a evaluar-sistema.mjs: añade el análisis de CALIBRACIÓN del
// clasificador y el desglose por pliegue, que son los puntos que la auditoría
// señaló. Las métricas comunes salen de tests/lib/evaluacion.mjs, así que las
// cifras coinciden exactamente con las del otro informe.
//
// Este script medía la arquitectura anterior, en la que las reglas emitían el
// veredicto y el modelo era decorativo. Esa arquitectura ya no existe: desde
// js/motor/decision.js el clasificador decide y las reglas solo ponen un piso.

import { entrenar } from "../js/motor/modelo.js";
import { UMBRAL } from "../js/motor/decision.js";
import {
  ADVERTENCIA, cargarTodo, cvEstratificada, resumenCv, retencionRepetida,
  evaluarConfiguraciones, calibracion, imprimirMetricas, porcentaje,
} from "./lib/evaluacion.mjs";

const { corpus, config, externo } = cargarTodo();
const modelo = entrenar(corpus);

console.log(ADVERTENCIA);

/* ---------- las tres configuraciones ---------- */

const r = evaluarConfiguraciones(modelo, config, externo);

console.log(`\n=== Conjunto externo (${externo.length} mensajes, SINTÉTICO) ===`);
imprimirMetricas("Solo el modelo", r.modelo);
imprimirMetricas("Solo las reglas", r.reglas);
imprimirMetricas("SISTEMA FINAL (modelo + piso)", r.sistema);
console.log(
  "\nEl sistema final no coincide con ninguna de las dos configuraciones\n" +
  "anteriores: el clasificador decide la etiqueta y las reglas solo elevan el\n" +
  "nivel de alerta cuando ven evidencia que el modelo no puede ver (enlaces y\n" +
  "peticiones de dinero o datos).",
);

/* ---------- corpus semilla, pliegue por pliegue ---------- */

const pliegues = cvEstratificada(corpus, 5);

console.log(`\n=== Corpus semilla (${corpus.length} mensajes, SINTÉTICO) ===`);
for (const campo of ["exactitud", "sensibilidad", "precision"]) {
  const s = resumenCv(pliegues, campo);
  console.log(
    `CV estratificada 5-fold ${campo.padEnd(13)} media=${porcentaje(s.media)}; ` +
    `DE=${(s.de * 100).toFixed(1)} pp; rango=${porcentaje(s.min)}–${porcentaje(s.max)}`,
  );
}

console.log("\nDesglose por pliegue (exactitud):");
pliegues.forEach((p, i) => {
  console.log(`  pliegue ${i + 1}: n=${p.n}; exactitud=${porcentaje(p.exactitud)}; VP=${p.vp} VN=${p.vn} FP=${p.fp} FN=${p.fn}`);
});

const ret = retencionRepetida(corpus);
console.log(
  `\nRetención 70/30, 10 semillas declaradas: exactitud media=${porcentaje(ret.media)}; ` +
  `rango=${porcentaje(ret.min)}–${porcentaje(ret.max)}`,
);
console.log("Es el protocolo anterior. Se conserva solo para mostrar por qué se cambió:");
console.log("no estratifica las clases y su resultado depende de la lista de semillas.");

/* ---------- calibración ---------- */

const cal = calibracion(r.probabilidades);

console.log("\n=== Calibración del clasificador sobre el conjunto externo ===");
for (const f of cal.filas) {
  console.log(
    `  banda ${f.desde.toFixed(1)}–${f.hasta.toFixed(1)}: n=${String(f.n).padStart(2)}; ` +
    `puntuación media=${porcentaje(f.probMedia).padStart(6)}; phishing observado=${porcentaje(f.observado)}`,
  );
}
console.log(`  puntuaciones extremas (<=5% o >=95%): ${cal.extremas}/${cal.total}`);
console.log(
  "\nConclusión: la puntuación del Naive Bayes NO está calibrada y se concentra\n" +
  `en los extremos. Por eso la interfaz la presenta como "similitud con el\n` +
  'corpus" y nunca como probabilidad de fraude. El umbral de decisión es ' + UMBRAL + ".",
);
